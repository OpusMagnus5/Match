public interface IMatchService {
    int getNextId();
    void saveMatch(Match match);
}
