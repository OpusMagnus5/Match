
import javax.ws.rs.Path;

@Path("/team")
public class TeamResources {
}
